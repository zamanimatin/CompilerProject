package main.visitor;

import main.ast.nodes.Program;
import main.ast.nodes.declaration.classDec.ClassDeclaration;
import main.ast.nodes.declaration.classDec.classMembersDec.ConstructorDeclaration;
import main.ast.nodes.declaration.classDec.classMembersDec.FieldDeclaration;
import main.ast.nodes.declaration.classDec.classMembersDec.MethodDeclaration;
import main.ast.nodes.declaration.variableDec.VarDeclaration;
import main.ast.nodes.expression.*;
import main.ast.nodes.expression.values.ListValue;
import main.ast.nodes.expression.values.NullValue;
import main.ast.nodes.expression.values.primitive.BoolValue;
import main.ast.nodes.expression.values.primitive.IntValue;
import main.ast.nodes.expression.values.primitive.StringValue;
import main.ast.nodes.statement.*;
import main.ast.nodes.statement.loop.BreakStmt;
import main.ast.nodes.statement.loop.ContinueStmt;
import main.ast.nodes.statement.loop.ForStmt;
import main.ast.nodes.statement.loop.ForeachStmt;
import main.symbolTable.SymbolTable;
import main.symbolTable.exceptions.ItemAlreadyExistsException;
import main.symbolTable.exceptions.ItemNotFoundException;
import main.symbolTable.items.ClassSymbolTableItem;
import main.symbolTable.items.FieldSymbolTableItem;
import main.symbolTable.items.MethodSymbolTableItem;
import main.symbolTable.items.SymbolTableItem;
import main.symbolTable.utils.Stack;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class SecondVisitor extends Visitor<Void> {

    @Override
    public Void visit(Program program) {
        SymbolTable root = new SymbolTable();
        SymbolTable.push(root);
        List<ClassDeclaration> classes = program.getClasses();
        for (int i = 0; i < classes.size(); i++){
            classes.get(i).accept(new SecondVisitor());
            ClassSymbolTableItem classSymbolTableItemNew = new ClassSymbolTableItem(classes.get(i));
            classSymbolTableItemNew.setClassSymbolTable(SymbolTable.root);
            SymbolTable.pop();
            try{
                root.put(classSymbolTableItemNew);
            }catch (ItemAlreadyExistsException E){
                System.out.println("Line:" + Integer.toString(classes.get(i).getLine()) + ":Redefinition of class " + classes.get(i).getClassName().getName());
                try {
                    classSymbolTableItemNew.setName(classSymbolTableItemNew.getName() + "SecondVisit" + Integer.toString(classes.get(i).getLine()));
                }catch(Exception e){}
            }
        }
        SymbolTable.root = root;
        return null;
    }

    @Override
    public Void visit(ClassDeclaration classDeclaration) {
        try{
            ClassSymbolTableItem CST = ((ClassSymbolTableItem) SymbolTable.root.getItem("Class_" + classDeclaration.getClassName().getName(), false));
            SymbolTable classST = CST.getClassSymbolTable();
            for (FieldDeclaration FieldDec : classDeclaration.getFields()){
                FieldDec.accept(new SecondVisitor());
                FieldSymbolTableItem newField = new FieldSymbolTableItem(FieldDec);
                newField.setName(FieldDec.getVarDeclaration().getVarName().getName());
                newField.setType(newField.getType());
                try{
                    SymbolTable.root.put(newField);
                }catch (ItemAlreadyExistsException E1){
                    System.out.println("Line:" + Integer.toString(FieldDec.getLine()) + ":Redefinition of Field " + FieldDec.getVarDeclaration().getVarName().getName());
                }
            }
            for (MethodDeclaration methodDec : classDeclaration.getMethods()){
                methodDec.accept(new SecondVisitor());
                MethodSymbolTableItem newMethod = new MethodSymbolTableItem(methodDec);
                newMethod.setMethodDeclaration(methodDec);
                MethodSymbolTableItem MSI = ((MethodSymbolTableItem) SymbolTable.root.getItem("Method_" + methodDec.getMethodName().getName(), false));
                SymbolTable MethodST = MSI.getMethodSymbolTable();
                newMethod.setMethodSymbolTable(MethodST);
                try{
                    SymbolTable.root.put(newMethod);
                }catch (ItemAlreadyExistsException E3){
                    System.out.println("Line:" + Integer.toString(methodDec.getLine()) + ":Redefinition of method " + methodDec.getMethodName().getName());
                }
                try{
                    if(SymbolTable.root.getItem("Field_" + methodDec.getMethodName().getName(), false) != null){
                        System.out.println("Line:" + Integer.toString(methodDec.getLine()) + ":Name of method " + methodDec.getMethodName().getName() + " conflicts with a field's name");
                    }
                }catch (ItemNotFoundException E4){}
            }
        }catch (Exception e){}
        return null;
    }

    @Override
    public Void visit(ConstructorDeclaration constructorDeclaration) {
        try{
            MethodSymbolTableItem MST = ((MethodSymbolTableItem) SymbolTable.top.getItem("Method_" + constructorDeclaration.getMethodName().getName(), false));
            SymbolTable constructorST = MST.getMethodSymbolTable();
            for(VarDeclaration varDec : constructorDeclaration.getLocalVars()){
                varDec.accept(new SecondVisitor());
                FieldDeclaration newField = new FieldDeclaration(varDec);
                FieldSymbolTableItem newVar = new FieldSymbolTableItem(newField);
                varDec.accept(new FirstVisitor());
                try{
                    SymbolTable.top.put(newVar);
                }catch (ItemAlreadyExistsException E1){
                    System.out.println("Line:" + Integer.toString(varDec.getLine()) + ":Redefinition of local variable "+ varDec.getVarName().getName());
                }
            }
        }catch (Exception e){}

        return null;
    }

    @Override
    public Void visit(MethodDeclaration methodDeclaration) {
        try {
            MethodSymbolTableItem MST = ((MethodSymbolTableItem) SymbolTable.top.getItem("Method_" + methodDeclaration.getMethodName().getName(), false));
            SymbolTable methodST = MST.getMethodSymbolTable();
            for (VarDeclaration varDec : methodDeclaration.getLocalVars()) {
                varDec.accept(new SecondVisitor());
                FieldDeclaration newField = new FieldDeclaration(varDec);
                FieldSymbolTableItem newVar = new FieldSymbolTableItem(newField);
                varDec.accept(new SecondVisitor());
                try {
                    SymbolTable.top.put(newVar);
                } catch (ItemAlreadyExistsException E1) {
                    System.out.println("Line:" + Integer.toString(varDec.getLine()) + ":Redefinition of local variable " + varDec.getVarName().getName());
                }
            }
        } catch (Exception e) {}
        return null;
    }

    @Override
    public Void visit(FieldDeclaration fieldDeclaration) {
        System.out.println("Line:" + Integer.toString(fieldDeclaration.getLine()) + ":" + fieldDeclaration.toString());
        fieldDeclaration.getVarDeclaration().accept(this);
        return null;
    }

    @Override
    public Void visit(VarDeclaration varDeclaration) {
        System.out.println("Line:" + Integer.toString(varDeclaration.getLine()) + ":" + varDeclaration.toString());
        varDeclaration.getVarName().accept(this);
        return null;
    }


//    @Override
//    public Void visit(AssignmentStmt assignmentStmt) {
//        System.out.println("Line:" + Integer.toString(assignmentStmt.getLine()) + ":" + assignmentStmt.toString());
//        assignmentStmt.getlValue().accept(this);
//        assignmentStmt.getrValue().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(BlockStmt blockStmt) {
//        System.out.println("Line:" + Integer.toString(blockStmt.getLine()) + ":" + blockStmt.toString());
//        for(Statement st : blockStmt.getStatements())
//            st.accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(ConditionalStmt conditionalStmt) {
//        System.out.println("Line:" + Integer.toString(conditionalStmt.getLine()) + ":" + conditionalStmt.toString());
//        conditionalStmt.getCondition().accept(this);
//        conditionalStmt.getThenBody().accept(this);
//        conditionalStmt.getElseBody().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(MethodCallStmt methodCallStmt) {
//        System.out.println("Line:" + Integer.toString(methodCallStmt.getLine()) + ":" + methodCallStmt.toString());
//        methodCallStmt.getMethodCall().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(PrintStmt print) {
//        System.out.println("Line:" + Integer.toString(print.getLine()) + ":" + print.toString());
//        print.getArg().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(ReturnStmt returnStmt) {
//        System.out.println("Line:" + Integer.toString(returnStmt.getLine()) + ":" + returnStmt.toString());
//        returnStmt.getReturnedExpr().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(BreakStmt breakStmt) {
//        System.out.println("Line:" + Integer.toString(breakStmt.getLine()) + ":" + breakStmt.toString());
//        return null;
//    }
//
//    @Override
//    public Void visit(ContinueStmt continueStmt) {
//        System.out.println("Line:" + Integer.toString(continueStmt.getLine()) + ":" + continueStmt.toString());
//        return null;
//    }
//
//    @Override
//    public Void visit(ForeachStmt foreachStmt) {
//        System.out.println("Line:" + Integer.toString(foreachStmt.getLine()) + ":" + foreachStmt.toString());
//        foreachStmt.getVariable().accept(this);
//        foreachStmt.getList().accept(this);
//        foreachStmt.getBody().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(ForStmt forStmt) {
//        System.out.println("Line:" + Integer.toString(forStmt.getLine()) + ":" + forStmt.toString());
//        forStmt.getInitialize().accept(this);
//        forStmt.getCondition().accept(this);
//        forStmt.getUpdate().accept(this);
//        forStmt.getBody().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(BinaryExpression binaryExpression) {
//        System.out.println("Line:" + Integer.toString(binaryExpression.getLine()) + ":" + binaryExpression.toString());
//        binaryExpression.getFirstOperand().accept(this);
//        binaryExpression.getSecondOperand().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(UnaryExpression unaryExpression) {
//        System.out.println("Line:" + Integer.toString(unaryExpression.getLine()) + ":" + unaryExpression.toString());
//        unaryExpression.getOperand().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(ObjectOrListMemberAccess objectOrListMemberAccess) {
//        System.out.println("Line:" + Integer.toString(objectOrListMemberAccess.getLine()) + ":" + objectOrListMemberAccess.toString());
//        objectOrListMemberAccess.getInstance().accept(this);
//        objectOrListMemberAccess.getMemberName().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(Identifier identifier) {
//        System.out.println("Line:" + Integer.toString(identifier.getLine()) + ":" + identifier.toString());
//        return null;
//    }
//
//    @Override
//    public Void visit(ListAccessByIndex listAccessByIndex) {
//        System.out.println("Line:" + Integer.toString(listAccessByIndex.getLine()) + ":" + listAccessByIndex.toString());
//        listAccessByIndex.getInstance().accept(this);
//        listAccessByIndex.getIndex().accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(MethodCall methodCall) {
//        System.out.println("Line:" + Integer.toString(methodCall.getLine()) + ":" + methodCall.toString());
//        methodCall.getInstance().accept(this);
//        for(Expression ex : methodCall.getArgs())
//            ex.accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(NewClassInstance newClassInstance) {
//        System.out.println("Line:" + Integer.toString(newClassInstance.getLine()) + ":" + newClassInstance.toString());
//        for(Expression ex : newClassInstance.getArgs())
//            ex.accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(ThisClass thisClass) {
//        System.out.println("Line:" + Integer.toString(thisClass.getLine()) + ":" + thisClass.toString());
//        return null;
//    }
//
//    @Override
//    public Void visit(ListValue listValue) {
//        System.out.println("Line:" + Integer.toString(listValue.getLine()) + ":" + listValue.toString());
//        for(Expression ex : listValue.getElements())
//            ex.accept(this);
//        return null;
//    }
//
//    @Override
//    public Void visit(NullValue nullValue) {
//        System.out.println("Line:" + Integer.toString(nullValue.getLine()) + ":" + nullValue.toString());
//        return null;
//    }
//
//    @Override
//    public Void visit(IntValue intValue) {
//        System.out.println("Line:" + Integer.toString(intValue.getLine()) + ":" + intValue.toString());
//        return null;
//    }
//
//    @Override
//    public Void visit(BoolValue boolValue) {
//        System.out.println("Line:" + Integer.toString(boolValue.getLine()) + ":" + boolValue.toString());
//        return null;
//    }
//
//    @Override
//    public Void visit(StringValue stringValue) {
//        System.out.println("Line:" + Integer.toString(stringValue.getLine()) + ":" + stringValue.toString());
//        return null;
//    }
//
}
