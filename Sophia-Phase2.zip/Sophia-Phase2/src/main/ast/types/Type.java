package main.ast.types;

import main.ast.nodes.Node;

public abstract class Type {
    public abstract String toString();
}
