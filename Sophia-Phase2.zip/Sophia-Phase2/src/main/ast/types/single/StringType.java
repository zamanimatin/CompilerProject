package main.ast.types.single;

import main.ast.types.Type;

public class StringType extends Type {
    @Override
    public String toString() {
        return "StringType";
    }
}
