package main.ast.nodes.statement;

import main.ast.nodes.Node;
import main.visitor.IVisitor;

public abstract class Statement extends Node {
}
