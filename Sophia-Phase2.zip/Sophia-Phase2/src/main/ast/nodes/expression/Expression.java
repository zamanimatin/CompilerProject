package main.ast.nodes.expression;


import main.ast.nodes.Node;
import main.ast.types.Type;

public abstract class Expression extends Node {
}
