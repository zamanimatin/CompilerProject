package main.ast.nodes.expression.operators;

public enum UnaryOperator {
    not, minus, preinc, postinc, predec, postdec
}