package main.ast.nodes.declaration;

import main.ast.nodes.Node;

public abstract class Declaration extends Node {
}
