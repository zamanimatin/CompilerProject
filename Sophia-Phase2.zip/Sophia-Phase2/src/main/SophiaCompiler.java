package main;

import main.ast.nodes.Program;
import main.visitor.ASTTreePrinter;
import main.visitor.FirstVisitor;
import main.visitor.SecondVisitor;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import parsers.SophiaLexer;
import parsers.SophiaParser;


public class SophiaCompiler {
    public void compile(CharStream textStream) {
        SophiaLexer sophiaLexer = new SophiaLexer(textStream);
        CommonTokenStream tokenStream = new CommonTokenStream(sophiaLexer);
        SophiaParser sophiaParser = new SophiaParser(tokenStream);
        Program program = sophiaParser.sophia().sophiaProgram;

        FirstVisitor Fv = new FirstVisitor();
        program.accept(Fv);
        SecondVisitor Sv = new SecondVisitor();
        program.accept(Sv);
        ASTTreePrinter printer = new ASTTreePrinter();
        program.accept(printer);

    }

}
